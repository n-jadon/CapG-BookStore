package com.capgemini.BookStore.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.BookStore.dto.Book;
import com.capgemini.BookStore.repo.BookRepo;
@Service(value = "bookServices")
public class BookServiceImpl implements BookServices{
	
	@Autowired
	private BookRepo bookRepo;

	@Override
	public Book addBook(Book book) {
		// TODO Auto-generated method stub
		return bookRepo.save(book);
	}

	@Override
	public Book[] searchBook(String bookName) {
		// TODO Auto-generated method stub
		return bookRepo.search(bookName);
	}

	@Override
	public Book deleteBook(Book book) {
		// TODO Auto-generated method stub
		Book tempBook=bookRepo.findOne(book.getBookId());
		if(tempBook!=null)
		bookRepo.delete(book);
		return tempBook;
	}

}

package com.capgemini.BookStore.services;

import com.capgemini.BookStore.dto.Customer;

public interface CustomerServices {
	public Customer addCustomer(Customer customer);

	public Customer updateCustomer(Customer customer);

	public Customer loginCustomer(Customer customer);
	
}

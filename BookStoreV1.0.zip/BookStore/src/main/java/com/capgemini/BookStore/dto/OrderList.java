package com.capgemini.BookStore.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;

@Entity
public class OrderList {
	
	@Id
	@Column(name = "orderid")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@NotNull
	private int orderId;
	
	@ManyToOne
	@NotNull
	private Customer customer;
	
	@Column(name = "address")
	@NotNull
	private String address;
	
	@Column(name = "city")
	@NotNull
	private String city;
	
	@Column(name = "zipcode")
	@NotNull
	private int zipcode;
	
	@Column(name = "country")
	@NotNull
	private String country;

	@Column(name = "total")
	@NotNull
	private double total;
	
	@Column(name = "paymentmethod")
	@NotNull
	private String paymentmethod;
	
	@Column(name = "orderstatus")
	@NotNull
	private String orderstatus;
}

package com.capgemini.BookStore.repo;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.BookStore.dto.Admin;

@Repository
@Transactional
public interface AdminRepo extends JpaRepository<Admin, Integer>{

	@Query("SELECT m FROM Admin m WHERE m.adminEmail =:adminEmail AND m.password=:password")
	Admin login(@Param("adminEmail")String adminEmail,@Param("password") String password);

}

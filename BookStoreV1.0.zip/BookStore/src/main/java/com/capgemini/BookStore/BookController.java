package com.capgemini.BookStore;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.BookStore.dto.Book;
import com.capgemini.BookStore.services.BookServices;

@RestController
@RequestMapping("books")
public class BookController {
	
	@Autowired
	BookServices bookService;
	
	@RequestMapping(method = RequestMethod.POST, value = "/addBook")
	public Book addBook(@RequestBody Book book, HttpServletRequest request) {
		return bookService.addBook(book);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/searchBook/{book}")
	public Book[] searchBook(@PathVariable("book") String bookName, HttpServletRequest request) {
		return bookService.searchBook(bookName);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/deleteBook")
	public Book deleteBook(@RequestBody Book book, HttpServletRequest request) {
		return bookService.deleteBook(book);
	}

}

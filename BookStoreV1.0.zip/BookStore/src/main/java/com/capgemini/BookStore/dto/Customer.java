package com.capgemini.BookStore.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "customerdetail")
public class Customer {
	@Id
	@Column(name = "customerid")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@NotNull
	private int customerId;
	
	@Column(name = "customername")
	@NotNull
	private String customerName;
	
	@Column(name = "email")
	@NotNull
	private String customerEmail;
	
	@Column(name = "password")
	@NotNull
	private String password;
	
	@Column(name = "phone")
	@NotNull
	private String phoneNo;
	
	@Column(name = "address")
	@NotNull
	private String address;
	
	@Column(name = "city")
	@NotNull
	private String city;
	
	@Column(name = "zipcode")
	@NotNull
	private int zipcode;
	
	@Column(name = "country")
	@NotNull
	private String country;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	

	public int getZipcode() {
		return zipcode;
	}

	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	
}

package com.capgemini.BookStore.repo;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.BookStore.dto.Book;


@Repository
@Transactional
public interface BookRepo extends JpaRepository<Book, Integer>{

	@Query("SELECT m FROM Book m WHERE m.title =:bookName")
	Book[] search(@Param("bookName")String bookName);

}

package com.capgemini.BookStore.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

@Entity
public class OrderDetail {
	@Id
	@Column(name = "orderdetailid")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@NotNull
	private int orderDetailId;
	
	@ManyToOne
	@NotNull
	private Book book;
	
	@ManyToOne
	@NotNull
	private OrderList order;
	
	@Column
	@NotNull
	private int quantity;
	
	@Column
	@NotNull
	private float subTotal;
}

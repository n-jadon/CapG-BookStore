package com.capgemini.BookStore.repo;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.BookStore.dto.Category;

@Repository
@Transactional
public interface CategoryRepo extends JpaRepository<Category, Integer>{

}

package com.capgemini.BookStore.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.BookStore.dto.Customer;
import com.capgemini.BookStore.repo.CustomerRepo;


@Service(value = "customerServices")
public class CustomerServiceImpl implements CustomerServices{
	
	@Autowired
	private CustomerRepo customerRepo;

	@Override
	public Customer addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerRepo.save(customer);
	}
	
	@Override
	public Customer updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerRepo.saveAndFlush(customer);
	}

	@Override
	public Customer loginCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerRepo.find(customer.getCustomerEmail(),customer.getPassword());
	}	

}

package com.capgemini.BookStore;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.BookStore.dto.Admin;
import com.capgemini.BookStore.dto.Category;
import com.capgemini.BookStore.services.AdminServices;

@RestController
@RequestMapping("admin")
public class AdminController {
	@Autowired
	AdminServices adminServices;
	
	@RequestMapping(method = RequestMethod.POST, value = "/registercustomer")
	public Admin registerUser(@RequestBody Admin admin, HttpServletRequest request) {
		System.out.println("1");
		return adminServices.addAdmin(admin);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/login")
	public Admin loginAdmin(@RequestBody Admin admin, HttpServletRequest request) {
		return adminServices.loginCustomer(admin);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/addCategory")
	public void addCategory(@RequestBody Category category, HttpServletRequest request) {
		adminServices.addCategory(category);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/getCategory")
	public ArrayList<Category> getCategory() {
		return adminServices.getCategory();
	}
	
}

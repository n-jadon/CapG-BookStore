package com.capgemini.BookStore.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.BookStore.dto.Admin;
import com.capgemini.BookStore.dto.Category;
import com.capgemini.BookStore.dto.Customer;
import com.capgemini.BookStore.repo.AdminRepo;
import com.capgemini.BookStore.repo.CategoryRepo;

@Service(value = "adminServices")
public class AdminServiceImpl implements AdminServices{

	@Autowired
	AdminRepo adminRepo;
	
	@Autowired
	CategoryRepo categoryRepo;
	
	@Override
	public Admin addAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return adminRepo.save(admin);
	}
	@Override
	public Admin loginCustomer(Admin admin) {
		// TODO Auto-generated method stub
		return adminRepo.login(admin.getAdminEmail(),admin.getPassword());
	}
	@Override
	public void addCategory(Category category) {
		// TODO Auto-generated method stub
		categoryRepo.save(category);
	}
	@Override
	public ArrayList<Category> getCategory() {
		// TODO Auto-generated method stub
		return (ArrayList<Category>) categoryRepo.findAll();
	}

}

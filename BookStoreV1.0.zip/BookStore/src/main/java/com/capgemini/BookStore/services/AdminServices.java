package com.capgemini.BookStore.services;

import java.util.ArrayList;

import com.capgemini.BookStore.dto.Admin;
import com.capgemini.BookStore.dto.Category;

public interface AdminServices {
	public Admin addAdmin(Admin admin);

	public Admin loginCustomer(Admin admin);
	
	public void addCategory(Category category);

	public ArrayList<Category> getCategory();
}

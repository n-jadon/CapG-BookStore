package com.capgemini.BookStore;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.BookStore.dto.Customer;
import com.capgemini.BookStore.services.CustomerServices;

@RestController
@RequestMapping("customer")
public class CustomerController {
	@Autowired
	CustomerServices customerServices;
	
	@RequestMapping(method = RequestMethod.POST, value = "/registercustomer")
	public Customer registerUser(@RequestBody Customer customer, HttpServletRequest request) {
		return customerServices.addCustomer(customer);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/updatecustomer")
	public Customer updateUser(@RequestBody Customer customer, HttpServletRequest request) {
		return customerServices.updateCustomer(customer);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/login")
	public Customer loginUser(@RequestBody Customer customer, HttpServletRequest request) {
		return customerServices.loginCustomer(customer);
	}
	
	
}

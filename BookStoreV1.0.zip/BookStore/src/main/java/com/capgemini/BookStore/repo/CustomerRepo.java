package com.capgemini.BookStore.repo;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.BookStore.dto.Customer;

@Repository
@Transactional
public interface CustomerRepo extends JpaRepository<Customer, Integer> {
	
	@Query("SELECT m FROM Customer m WHERE m.customerEmail =:customerEmail AND m.password=:password")
	Customer find(@Param("customerEmail")String customerEmail,@Param("password") String password);
}

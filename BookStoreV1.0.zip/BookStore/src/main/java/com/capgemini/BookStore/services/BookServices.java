package com.capgemini.BookStore.services;

import com.capgemini.BookStore.dto.Book;

public interface BookServices {
	public Book addBook(Book book);
	public Book[] searchBook(String bookName);
	public Book deleteBook(Book book);
}

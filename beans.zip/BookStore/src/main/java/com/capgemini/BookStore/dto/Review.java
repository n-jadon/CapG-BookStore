package com.capgemini.BookStore.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "admindetail")
public class Review {
	
	@Id
	@Column(name = "reviewid")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@NotNull
	private int reviewId;
	
	@Column
	@NotNull
	private Customer customer;

	@Column
	@NotNull
	private Book book;
	
	@Column
	@NotNull
	private int rating;
	
	@Column
	@NotNull
	private String headline;
	
	@Column
	@NotNull
	private String comment;
}

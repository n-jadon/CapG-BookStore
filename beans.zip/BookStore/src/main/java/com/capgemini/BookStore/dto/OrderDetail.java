package com.capgemini.BookStore.dto;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

public class OrderDetail {
	@Id
	@Column(name = "orderdetailid")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@NotNull
	private int orderDetailId;
	
	@Column
	@NotNull
	private Book book;
	
	@Column
	@NotNull
	private OrderList order;
	
	@Column
	@NotNull
	private int quantity;
	
	@Column
	@NotNull
	private float subTotal;
}
